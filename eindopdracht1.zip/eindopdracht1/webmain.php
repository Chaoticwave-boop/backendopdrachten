<html>
    <head >
        <link  rel="stylesheet" type="text/css" href="web.css"/>
    </head>

    <body>
        <?php 
            include("web.php")
        ?>

    <style type="text/css">
        body
            {
                background-image:url('<?php echo $background ?>');
            }
    </style>
    </body>
</html>